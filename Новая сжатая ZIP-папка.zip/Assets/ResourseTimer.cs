using TMPro;
using UnityEngine;
using UnityEngine.UI;

// ИСПРАВЛЕНО: Имя класса теперь точно ResourceTimer (через 'c')
public class ResourceTimer : MonoBehaviour
{
    [SerializeField] private float duration;
    [SerializeField] private Slider timerProgressBar;
    [SerializeField] private TextMeshProUGUI resourceText;

    public int _resourceAmount { get; private set; }
    private float _currTimer;
    private const int _resourceStep = 3;

    private void Awake()
    {
        if (resourceText != null)
            resourceText.text = $"Resource: {_resourceAmount}";

        StartTimer();
    }

    private void StartTimer()
    {
        _currTimer = 0;
    }

    private void Update()
    {
        RunTimer();
    }

    private void RunTimer()
    {
        if (_currTimer < duration)
        {
            _currTimer += Time.deltaTime;
            timerProgressBar.value = _currTimer / duration;
        }
        else
        {
            AddResource();
            StartTimer();
        }
    }

    private void DrawResouce()
    {
        if (resourceText != null)
            resourceText.text = $"Resource: {_resourceAmount}";
    }

    private void AddResource()
    {
        _resourceAmount += _resourceStep;
        DrawResouce();
    }
}