using UnityEngine;
using UnityEngine.UI;

public class timer : MonoBehaviour
{
    [SerializeField] private float duration;
    [SerializeField] private Image timerProgressBar;
    [SerializeField] private Button startButton;

    // ИСПРАВЛЕНО: Теперь пишется ResourceTimer (через 'c'), чтобы совпадать с вашим вторым скриптом
    [SerializeField] private ResourceTimer resourceTimer;

    private float _currtimer;
    private bool _isTimerRunning;
    private const int MinResourceAmount = 5;

    private float Currtimer
    {
        get => _currtimer;
        set
        {
            _currtimer = value;
            if (_currtimer <= 0)
            {
                // ИСПРАВЛЕНО: Проверяем _resourceAmount (с нижним подчеркиванием)
                if (resourceTimer != null && resourceTimer._resourceAmount >= MinResourceAmount)
                {
                    startButton.interactable = true;
                }

                timerProgressBar.fillAmount = 1f;
                _isTimerRunning = false;
            }
        }
    }

    private void Awake()
    {
        startButton.onClick.AddListener(StartTimer);
    }

    private void StartTimer()
    {
        startButton.interactable = false;
        Currtimer = duration;
        _isTimerRunning = true;
    }

    private void Update()
    {
        RunTimer();
    }

    private void RunTimer()
    {
        if (_isTimerRunning && Currtimer > 0)
        {
            Currtimer -= Time.deltaTime;
            timerProgressBar.fillAmount = Currtimer / duration;
        }
    }
}